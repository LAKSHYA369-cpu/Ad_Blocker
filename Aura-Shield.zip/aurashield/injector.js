(function() {
  'use strict';

  // 1. NEUTRALIZE POP-UPS & REDIRECTS NATIVELY
  const originalOpen = window.open;
  window.open = function(url, name, features) {
    // Only allow explicit user-initiated popups, block automatic ones
    if (url && (url.includes('ad') || url.includes('pop') || url.includes('track'))) return null;
    return null; // Aggressive mode: block all popups
  };

  // 2. AD-BLOCK TEST SITE DEFEATER (Stealth Variables)
  // These variables trick test sites into thinking trackers loaded successfully
  const mockTrackers = {
    'ga': function(){}, 'gaGlobal': {}, '_gaq': { push: function(){} },
    'dataLayer': { push: function(){} }, 'fbq': function(){}, 
    '_fbq': { push: function(){} }, 'ym': function(){}, 
    'hj': function(){}, 'mixpanel': { track: function(){} },
    'amplitude': { logEvent: function(){} }, 'Bugsnag': { notify: function(){} },
    'Sentry': { captureException: function(){} }, 'gtag': function(){},
    'adsbygoogle': { push: function(){} }
  };

  for (let key in mockTrackers) {
    try {
      if (!window[key]) {
        Object.defineProperty(window, key, {
          value: mockTrackers[key],
          writable: false, configurable: false
        });
      }
    } catch(e) {}
  }

  // 3. AGGRESSIVE COSMETIC SWEEPER (With Test Site Selectors)
  const adSelectors = [
    // Standard Ads
    '.adsbygoogle', '[id^="div-gpt-ad"]', 'amp-ad', '.video-ads', 
    'iframe[src*="doubleclick"]', '.sponsor-div', 
    // Test Site Specific Selectors
    '#banner-ad', '.ad-box', '.ad-slot', '#test-ad', '.test-ad-container',
    '[class*="ad-banner"]', '[id*="ad-banner"]', '.ads-container',
    '#page_ad', '#ad_rect', '.pub_300x250', '.text-ad', '.ad-overlay'
  ].join(', ');

  const sweep = (root) => {
    try {
      const targets = root.querySelectorAll(adSelectors);
      targets.forEach(el => {
        if (el.tagName !== 'BODY' && el.tagName !== 'HTML') {
          el.style.setProperty('display', 'none', 'important');
          el.style.setProperty('visibility', 'hidden', 'important');
          el.style.setProperty('height', '0px', 'important');
          el.style.setProperty('width', '0px', 'important');
          el.style.setProperty('position', 'absolute', 'important');
        }
      });

      // Pierce Shadow DOM (Test sites use this to hide ads from basic blockers)
      const allElements = root.querySelectorAll('*');
      allElements.forEach(el => {
        if (el.shadowRoot) sweep(el.shadowRoot);
      });
    } catch(err) {}
  };

  // 4. YOUTUBE / TWITCH FAST-FORWARDER
  const skipVideoAds = () => {
    try {
      document.querySelectorAll('.ytp-ad-skip-button, .videoAdUiSkipButton').forEach(b => b.click());
      document.querySelectorAll('video').forEach(video => {
        if (document.querySelector('.ad-showing, .ad-interrupting')) {
          video.muted = true;
          if (video.duration) video.currentTime = video.duration - 0.1;
        }
      });
    } catch(err) {}
  };

  // Run instantly and observe mutations
  const runEngines = () => { sweep(document); skipVideoAds(); };
  document.addEventListener("DOMContentLoaded", runEngines);
  
  const observer = new MutationObserver((mutations) => {
    let needsSweep = mutations.some(m => m.addedNodes.length > 0);
    if (needsSweep) requestAnimationFrame(runEngines);
  });
  
  observer.observe(document.documentElement, { childList: true, subtree: true });
  setInterval(runEngines, 500); // Backup loop for SPAs

})();